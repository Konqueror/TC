﻿namespace Abstraction
{
    public interface IFigure
    {
        double CalcPerimeter();

        double CalcSurface();
    }
}
